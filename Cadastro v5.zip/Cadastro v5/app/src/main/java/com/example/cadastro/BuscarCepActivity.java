package com.example.cadastro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class BuscarCepActivity extends AppCompatActivity {



    private Button btnBuscarCEP;
    private EditText editBuscarCEP;
    private EditText editLogradouro;
    private EditText editNumRua;
    private EditText editComplemento;
    private EditText editBairro;
    private EditText editCidade;
    private EditText editEstado;

    private Button btnSalvarEndereco;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_cep);

        btnBuscarCEP = findViewById(R.id.btnBuscarCEP);
        editBuscarCEP = findViewById(R.id.editBuscarCEP);
        editLogradouro = findViewById(R.id.editLogradouro);
        editNumRua = findViewById(R.id.editNumRua);
        editComplemento = findViewById(R.id.editComplemento);
        editBairro = findViewById(R.id.editBairro);
        editCidade = findViewById(R.id.editCidade);
        editEstado = findViewById(R.id.editEstado);
        btnSalvarEndereco = findViewById(R.id.btnSalvarEndereco);
    }

    public void irParaCadastro(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}