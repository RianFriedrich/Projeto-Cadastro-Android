package com.example.cadastro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Patterns;

import java.util.ArrayList;
import java.util.List;

public class AlunoDao {

    private SQLiteDatabase db;
    private Conexao conexao;

    public AlunoDao(Context context) {
        conexao = new Conexao(context);
    }

    public long inserir(Aluno aluno) {
        db = conexao.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(Conexao.COLUMN_NOME, aluno.getNome());
        values.put(Conexao.COLUMN_CPF, aluno.getCpf());
        values.put(Conexao.COLUMN_TELEFONE, aluno.getTelefone());
        values.put(Conexao.COLUMN_FOTO_BYTES, aluno.getFotoBytes());

        long id = -1;
        try {
            id = db.insertOrThrow(Conexao.TABLE_ALUNO, null, values);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
        return id;
    }

    public void excluir(Aluno a) {
        db.delete("aluno", "id = ?", new String[]{a.getId().toString()});
    }

    public void atualizar(Aluno aluno) {
        db = conexao.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(Conexao.COLUMN_NOME, aluno.getNome());
        values.put(Conexao.COLUMN_CPF, aluno.getCpf());
        values.put(Conexao.COLUMN_TELEFONE, aluno.getTelefone());
        values.put(Conexao.COLUMN_FOTO_BYTES, aluno.getFotoBytes());

        db.update(Conexao.TABLE_ALUNO, values, Conexao.COLUMN_ID + " = ?", new String[]{String.valueOf(aluno.getId())});
        db.close();
    }

    public void deletar(int id) {
        db = conexao.getWritableDatabase();
        db.delete(Conexao.TABLE_ALUNO, Conexao.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public boolean cpfExistente(String cpf) {
        db = conexao.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + Conexao.TABLE_ALUNO + " WHERE " + Conexao.COLUMN_CPF + " = ?", new String[]{cpf});
        boolean existe = false;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                existe = cursor.getInt(0) > 0;
            }
            cursor.close();
        }
        db.close();
        return existe;
    }

    public boolean validaCpf(String cpf) {
        return cpf.matches("\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}");
    }

    public boolean validaTelefone(String telefone) {
        return telefone.matches("\\(\\d{2}\\) 9\\d{4}-\\d{4}");
    }

    public List<Aluno> obterTodos() {
        List<Aluno> alunos = new ArrayList<>();
        db = conexao.getReadableDatabase();

        Cursor cursor = db.query(Conexao.TABLE_ALUNO,
                null, null, null, null, null, Conexao.COLUMN_NOME + " ASC");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Aluno aluno = new Aluno();
                aluno.setId(cursor.getInt(cursor.getColumnIndexOrThrow(Conexao.COLUMN_ID)));
                aluno.setNome(cursor.getString(cursor.getColumnIndexOrThrow(Conexao.COLUMN_NOME)));
                aluno.setCpf(cursor.getString(cursor.getColumnIndexOrThrow(Conexao.COLUMN_CPF)));
                aluno.setTelefone(cursor.getString(cursor.getColumnIndexOrThrow(Conexao.COLUMN_TELEFONE)));
                aluno.setFotoBytes(cursor.getBlob(cursor.getColumnIndexOrThrow(Conexao.COLUMN_FOTO_BYTES)));

                alunos.add(aluno);
            }
            cursor.close();
        }
        db.close();
        return alunos;
    }


    public Aluno buscarPorCpf(String cpf) {
        db = conexao.getReadableDatabase();
        Aluno aluno = null;

        Cursor cursor = db.query(Conexao.TABLE_ALUNO,
                null,
                Conexao.COLUMN_CPF + " = ?",
                new String[]{cpf},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            aluno = new Aluno();
            aluno.setId(cursor.getInt(cursor.getColumnIndexOrThrow(Conexao.COLUMN_ID)));
            aluno.setNome(cursor.getString(cursor.getColumnIndexOrThrow(Conexao.COLUMN_NOME)));
            aluno.setCpf(cursor.getString(cursor.getColumnIndexOrThrow(Conexao.COLUMN_CPF)));
            aluno.setTelefone(cursor.getString(cursor.getColumnIndexOrThrow(Conexao.COLUMN_TELEFONE)));
            aluno.setFotoBytes(cursor.getBlob(cursor.getColumnIndexOrThrow(Conexao.COLUMN_FOTO_BYTES)));

            cursor.close();
        }
        db.close();
        return aluno;
    }
}
