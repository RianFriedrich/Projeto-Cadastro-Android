// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
}
val compileSdkVersion by extra(24)
val compileSdkVersion1 by extra(compileSdkVersion)
