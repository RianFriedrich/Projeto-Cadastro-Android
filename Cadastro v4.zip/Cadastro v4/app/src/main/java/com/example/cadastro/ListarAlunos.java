package com.example.cadastro;

public class ListarAlunos {
}
