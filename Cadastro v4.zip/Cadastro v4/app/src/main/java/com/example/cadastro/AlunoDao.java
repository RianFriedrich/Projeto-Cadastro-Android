package com.example.cadastro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class AlunoDao {

    private Conexao conexao;
    private SQLiteDatabase banco;

    public AlunoDao(Context context) {
        conexao = new Conexao(context); // Criando instância de Conexao
        banco = conexao.getWritableDatabase(); // Acessando o banco para escrita
    }

    public long inserir(Aluno aluno) {
        if(!cpfExistente(aluno.getCpf())){
            ContentValues values = new ContentValues();
            values.put("nome", aluno.getNome());
            values.put("telefone", aluno.getTelefone());
            values.put("cpf", aluno.getCpf());
            values.put("fotoBytes", aluno.getFotoBytes());
            return banco.insert("aluno", null, values);
        }
        else{
            return -1;
        }
    }

    // Método para excluir um aluno do banco de dados
    public void excluir(Aluno a) {
        banco.delete("aluno", "id = ?", new String[]{a.getId().toString()});
    }

    public void atualizar(Aluno aluno) {
        ContentValues values = new ContentValues();
        values.put("nome", aluno.getNome());
        values.put("cpf", aluno.getCpf());
        values.put("telefone", aluno.getTelefone());
        values.put("fotoBytes", aluno.getFotoBytes());
        banco.update("aluno", values, "id = ?", new String[]{aluno.getId().toString()});
    }

    public List<Aluno> obterTodos() {
        List<Aluno> alunos = new ArrayList<>();
        Log.d("AlounoDao", "obterTodos" + alunos.size() + 1 + "Alunos Encontrados:");

        Cursor cursor = conexao.getReadableDatabase().query(
                "aluno", new String[]{"id", "nome", "cpf", "telefone", "fotoBytes"},
                null, null, null, null, null
        );

        while (cursor.moveToNext()) {
            Aluno a = new Aluno();
            a.setId(cursor.getInt(0));       // ID
            a.setNome(cursor.getString(1));  // Nome
            a.setCpf(cursor.getString(2));   // CPF (Corrigido)
            a.setTelefone(cursor.getString(3)); // Telefone (Adicionado)
            alunos.add(a);
        }
        cursor.close(); // Fechar o cursor para evitar vazamento de memória
        return alunos;
    }

    public boolean validaCpf(String cpf) {
        if (cpf == null || cpf.length() != 11 || !cpf.matches("\\d+")) {
            return false;
        }

        int[] pesos1 = {10, 9, 8, 7, 6, 5, 4, 3, 2};
        int[] pesos2 = {11, 10, 9, 8, 7, 6, 5, 4, 3, 2};

        try {
            int soma = 0;
            for (int i = 0; i < 9; i++) {
                soma += Character.getNumericValue(cpf.charAt(i)) * pesos1[i];
            }
            int resto = soma % 11;
            int primeiroDigito = (resto < 2) ? 0 : (11 - resto);

            if (Character.getNumericValue(cpf.charAt(9)) != primeiroDigito) {
                return false;
            }

            soma = 0;
            for (int i = 0; i < 10; i++) {
                soma += Character.getNumericValue(cpf.charAt(i)) * pesos2[i];
            }
            resto = soma % 11;
            int segundoDigito = (resto < 2) ? 0 : (11 - resto);

            return Character.getNumericValue(cpf.charAt(10)) == segundoDigito;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean cpfExistente(String cpf) {
        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM aluno WHERE cpf = ?", new String[]{cpf});

        if (cursor != null) {
            cursor.moveToFirst();
            int count = cursor.getInt(0);
            cursor.close();
            return count > 0;
        }

        return false;
    }

    public boolean validaTelefone(String telefone) {
        return telefone != null && telefone.matches("\\(\\d{2}\\) 9\\d{4}-\\d{4}");
    }
}
