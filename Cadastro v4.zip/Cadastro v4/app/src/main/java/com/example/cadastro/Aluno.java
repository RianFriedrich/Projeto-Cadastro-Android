package com.example.cadastro;

import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Aluno implements Serializable {


    private byte[] fotoBytes;

    public byte[] getFotoBytes() {return fotoBytes; }

    public void setFotoBytes(byte[] fotoBytes) {this.fotoBytes = fotoBytes; }
    private Integer id;

    private String nome;

    private String telefone;

    private String cpf;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }


    @Override
    public String toString() {
        return nome;
    }
}
